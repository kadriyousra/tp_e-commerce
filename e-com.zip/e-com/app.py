from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ecommerce.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'secret'

db = SQLAlchemy(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    image = db.Column(db.String(255), nullable=False)
    stock = db.Column(db.Integer, nullable=False)

# Création des tables avant le lancement de l'application
with app.app_context():
    db.create_all()

    # Ajout de produits si la base est vide
    if not Product.query.first():
        sample_products = [
            Product(name="Laptop", price=799.99, image="laptop.jpg", stock=10),
            Product(name="Smartphone", price=499.99, image="smart1.jpg", stock=15),
            Product(name="Casque Bluetooth", price=59.99, image="casque.jpg", stock=20),
            Product(name="Souris Gamer", price=29.99, image="souris.jpg", stock=30),
            Product(name="Clavier Mécanique", price=89.99, image="clavier.jpg", stock=25),
        ]
        db.session.add_all(sample_products)
        db.session.commit()

@app.route('/')
def index():
    products = Product.query.all()
    return render_template('index.html', products=products)

@app.route('/cart')
def cart():
    cart_items = session.get('cart', {})
    cart_data = []
    total_price = 0

    for product_id, quantity in cart_items.items():
        product = Product.query.get(product_id)
        if product:
            total_price += product.price * quantity
            cart_data.append({'product': product, 'quantity': quantity})

    return render_template('cart.html', cart_items=cart_data, total_price=total_price)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    product = Product.query.get(product_id)
    if not product or product.stock <= 0:
        return jsonify({'error': 'Stock insuffisant'}), 400

    if 'cart' not in session:
        session['cart'] = {}

    cart = session['cart']
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    session.modified = True

    return jsonify({'cart_count': sum(cart.values())})

@app.route('/decrease_cart/<int:product_id>', methods=['POST'])
def decrease_cart(product_id):
    if 'cart' in session and str(product_id) in session['cart']:
        session['cart'][str(product_id)] -= 1

        if session['cart'][str(product_id)] <= 0:
            del session['cart'][str(product_id)]  # Supprimer si quantité = 0

        session.modified = True

    return jsonify({'cart_count': sum(session['cart'].values()) if session['cart'] else 0})

@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    if 'cart' in session and str(product_id) in session['cart']:
        del session['cart'][str(product_id)]
        session.modified = True

    return jsonify({'cart_count': sum(session['cart'].values()) if session['cart'] else 0})

@app.route('/clear_cart')
def clear_cart():
    session.pop('cart', None)
    return redirect(url_for('cart'))

if __name__ == '__main__':
    app.run(debug=True)
